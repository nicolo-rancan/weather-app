# WeatherApp

##### A weather application developed using OpenWeatherMap's api

[OpenWeatherMap](https://openweathermap.org/)
